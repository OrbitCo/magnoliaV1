<?php

use Pg\modules\virtual_gifts\models\VirtualGiftsModel;

return [];
