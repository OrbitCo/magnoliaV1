<?php
return [
    [
        'module_gid' => 'virtual_gifts',
        'controller' => 'virtual_gifts',
        'method' => 'ajax_get_gifts_form',
        'access' => 2
    ]
];
