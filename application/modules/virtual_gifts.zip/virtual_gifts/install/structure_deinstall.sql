DROP TABLE IF EXISTS `[prefix]virtual_gifts`;
DROP TABLE IF EXISTS `[prefix]virtual_gifts_users`;
