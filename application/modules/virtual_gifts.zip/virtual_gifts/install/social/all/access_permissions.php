<?php
return [
    [
        'module_gid' => 'virtual_gifts',
        'controller' => 'virtual_gifts',
        'method' => null,
        'access' => 2
    ]
];
