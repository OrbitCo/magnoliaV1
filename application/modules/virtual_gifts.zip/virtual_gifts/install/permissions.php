<?php

$_permissions["admin_virtual_gifts"]["ajax_change_price"] = 3;
$_permissions["admin_virtual_gifts"]["ajax_change_price_form"] = 3;
$_permissions["admin_virtual_gifts"]["ajax_delete_gifts"] = 3;
$_permissions["admin_virtual_gifts"]["ajax_get_gift_images"] = 3;
$_permissions["admin_virtual_gifts"]["ajax_save_gift_media"] = 3;
$_permissions["admin_virtual_gifts"]["delete"] = 3;
$_permissions["admin_virtual_gifts"]["gift_status"] = 3;
$_permissions["admin_virtual_gifts"]["index"] = 3;
$_permissions["admin_virtual_gifts"]["settings"] = 3;
$_permissions["admin_virtual_gifts"]["sort_gifts"] = 3;
$_permissions["admin_virtual_gifts"]["upload"] = 3;
$_permissions["virtual_gifts"]["ajax_get_gift_data"] = 2;
$_permissions["virtual_gifts"]["ajax_get_gifts_form"] = 2;
$_permissions["virtual_gifts"]["ajax_get_receipt_gift"] = 2;
$_permissions["virtual_gifts"]["ajax_get_user_gifts"] = 2;
$_permissions["virtual_gifts"]["ajax_send_gift"] = 2;
$_permissions["virtual_gifts"]["ajax_send_gift_payment"] = 2;
$_permissions["virtual_gifts"]["ajax_user_gift_status"] = 2;
$_permissions["virtual_gifts"]["send_gift_payment"] = 2;
$_permissions["virtual_gifts"]["user_gift_status"] = 2;
$_permissions["api_virtual_gifts"]["getGifts"] = 2;
$_permissions["api_virtual_gifts"]["sendGiftPayment"] = 2;
$_permissions["api_virtual_gifts"]["getUserGifts"] = 2;
$_permissions["api_virtual_gifts"]["userGiftStatus"] = 2;
