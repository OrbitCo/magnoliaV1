<?php

$install_settings['virtual_gifts_counter'] = '0';
$install_settings['payment_type'] = 'account';
$install_settings['admin_items_per_page'] = '10';
$install_settings['user_items_per_page'] = '10';
$install_settings['price_default'] = '1.00';
