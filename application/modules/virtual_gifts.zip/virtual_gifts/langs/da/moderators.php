<?php

$install_lang["index"] = "Virtual gifts";
