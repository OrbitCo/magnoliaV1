<?php

$install_lang["virtual_gifts"] = "Virtual gift";
