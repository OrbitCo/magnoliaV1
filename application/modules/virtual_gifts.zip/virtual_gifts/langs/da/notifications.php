<?php

$install_lang["notification_virtual_gifts"] = "Someone sent you a gift";
$install_lang["tpl_virtual_gifts_content"] = "Hello [profile_nickname], \n\n[user_nickname] has sent you a gift. To view it, log into the site [domain].\n\nBest regards,\n[name_from].";
$install_lang["tpl_virtual_gifts_subject"] = "Someone sent you a gift";
