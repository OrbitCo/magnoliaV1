<?php

$install_lang["admin_menu_other_items_add_ons_items_virtual_gifts_menu_item"] = "Virtual gifts";
$install_lang["admin_menu_other_items_add_ons_items_virtual_gifts_menu_item_tooltip"] = "Virtual gifts module settings";
$install_lang["admin_page_menu_more-matches-items_virtual_gifts_menu_item"] = "Virtual gifts";
$install_lang["admin_page_menu_more-matches-items_virtual_gifts_menu_item_tooltip"] = "Virtual gifts module settings";
$install_lang["admin_virtual_gifts_menu_virtual_gifts_list_item"] = "Pictures";
$install_lang["admin_virtual_gifts_menu_virtual_gifts_list_item_tooltip"] = "";
$install_lang["admin_virtual_gifts_menu_virtual_gifts_settings_item"] = "Settings";
$install_lang["admin_virtual_gifts_menu_virtual_gifts_settings_item_tooltip"] = "";
