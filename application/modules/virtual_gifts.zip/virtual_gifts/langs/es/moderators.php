<?php

$install_lang["index"] = "Regalos virtuales";
