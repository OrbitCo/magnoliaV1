<?php

$install_lang["notification_virtual_gifts"] = "Alguien le envió un regalo";
$install_lang["tpl_virtual_gifts_content"] = "¡Hola [profile_nickname]! \n\n[user_nickname] le envió un regalo. Para verlo, inicie sesión en el sitio [domain].\n\nAtentamente,\n[name_from]";
$install_lang["tpl_virtual_gifts_subject"] = "Alguien le envió un regalo";
