<?php

$install_lang["virtual_gifts"] = "Regalo virtual";
