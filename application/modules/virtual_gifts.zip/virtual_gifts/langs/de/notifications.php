<?php

$install_lang["notification_virtual_gifts"] = "Sie haben ein Geschenk";
$install_lang["tpl_virtual_gifts_content"] = "Hallo [profile_nickname], \n\n[user_nickname] hat Ihnen ein Geschenk gesendet. Zum Anschauen bitte einloggen: [domain].\n\nMit freundlichen Grüßen,\n[name_from]";
$install_lang["tpl_virtual_gifts_subject"] = "Sie haben ein Geschenk";
