<?php

$install_lang["index"] = "Virtuelle Geschenke";
