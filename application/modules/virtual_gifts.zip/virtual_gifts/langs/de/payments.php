<?php

$install_lang["virtual_gifts"] = "Virtuelles Geschenk";
