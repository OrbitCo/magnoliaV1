<?php

$install_lang["notification_virtual_gifts"] = "Quelqu'un vous a envoyé un cadeau";
$install_lang["tpl_virtual_gifts_content"] = "Bonjour [profile_nickname],\n\n [user_nickname] vous a envoyé un cadeau. Pour le voir, connectez-vous au site [domain].\n\nCordialement,\n[name_from].";
$install_lang["tpl_virtual_gifts_subject"] = "Quelqu'un vous a envoyé un cadeau";
