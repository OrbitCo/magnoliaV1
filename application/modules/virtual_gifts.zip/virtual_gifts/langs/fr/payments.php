<?php

$install_lang["virtual_gifts"] = "Cadeau virtuel";
