<?php

$install_lang["notification_virtual_gifts"] = "Вам прислали подарок";
$install_lang["tpl_virtual_gifts_content"] = "Здравствуйте, [profile_nickname]! \n\nВам подарок от пользователя [user_nickname]. Чтобы посмотреть подарок, зайдите на сайт [domain].\n\nС наилучшими пожеланиями,\n[name_from]";
$install_lang["tpl_virtual_gifts_subject"] = "Вам прислали подарок";
