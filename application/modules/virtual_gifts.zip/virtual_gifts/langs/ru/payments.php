<?php

$install_lang["virtual_gifts"] = "Виртуальный подарок";
