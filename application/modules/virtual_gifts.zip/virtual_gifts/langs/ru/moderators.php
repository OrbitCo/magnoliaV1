<?php

$install_lang["index"] = "Виртуальные подарки";
