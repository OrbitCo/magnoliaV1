<?php

$install_lang["index"] = "Presentes virtuais";
