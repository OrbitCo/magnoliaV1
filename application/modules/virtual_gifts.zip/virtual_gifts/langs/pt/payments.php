<?php

$install_lang["virtual_gifts"] = "Presente virtual";
