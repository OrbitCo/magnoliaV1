<?php

$install_lang["notification_virtual_gifts"] = "Alguém lhe enviou um presente";
$install_lang["tpl_virtual_gifts_content"] = "Olá [profile_nickname], \n\n[user_nickname] enviou-lhe um presente. Para vê-lo, entre no site [domain].\n\nAtentamente,\n[name_from].";
$install_lang["tpl_virtual_gifts_subject"] = "Alguém lhe enviou um presente";
