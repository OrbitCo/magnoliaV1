<?php

$install_lang["admin_menu_content_items_add_ons_items_twilio_chat_menu_item"] = "Twilio чат";
$install_lang["admin_menu_content_items_add_ons_items_twilio_chat_menu_item_tooltip"] = "Twilio настройки чата";
