DROP TABLE IF EXISTS `[prefix]twilio_video_chat`
