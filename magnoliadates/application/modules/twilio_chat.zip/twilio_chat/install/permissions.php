<?php

$_permissions["admin_twilio_chat"]["settings"] = "3";

$_permissions["twilio_chat"]["get_room"] = "2";

$_permissions["twilio_chat"]["get_status_room"] = "2";
$_permissions["twilio_chat"]["set_status_room"] = "2";

$_permissions["twilio_chat"]["callback_room_status"] = "1";
$_permissions["twilio_chat"]["callback_room_settings"] = "1";
