<?php

return [
    [
        'module_gid' => 'twilio_chat',
        'controller' => 'twilio_chat',
        'method' => null,
        'access' => 2
    ]
];
