<?php

return [
    'fee_currency' => '%'
];
