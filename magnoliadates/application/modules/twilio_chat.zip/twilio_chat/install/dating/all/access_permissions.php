<?php

return [
    [
        'module_gid' => 'twilio_chat',
        'controller' => 'twilio_chat',
        'method' => null,
        'not_methods' => [
            'get_status_room',
            'set_status_room',
        ],
        'access' => 2
    ]
];
